
import java.util.Scanner;

public class TesteAnsiedade {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        // array das questions
        String[] perguntas = {
            "1. Você se sente com dificuldade de concentração?",
            "2. Você se sente cansado facilmente?",
            "3. Tem dificuldade em adormecer ou permanecer a dormir?",
            "4. Você se preocupa muito com o futuro?",
            "5. Tem dificuldade em relaxar?",
            "6. Sentiu-se tão preocupado que foi difícil ficar parado?",
            "7. Sentiu-se facilmente irritável ou chateado?",
            "8. Sentiu medo como se algo muito ruim fosse acontecer?",
            "9. Você se preocupa com a opinião dos outros?",
            "10. Você está com dificuldade em lembrar de detalhes?"
        };
        
        // array das answers
        boolean[] respostas = new boolean[perguntas.length];
        int respostasPositivas = 0;
        
        // loop das perguntas
        for (int i = 0; i < perguntas.length; i++) {
            System.out.println(perguntas[i]);
            System.out.print("Responda (sim/não): ");
            String resposta = scanner.next().toLowerCase();
            
            // Considerando 'sim' como resposta positiva
            if (resposta.equals("sim")) {
                respostas[i] = true;
                respostasPositivas++;
            } else {
                respostas[i] = false;
            }
        }
        
        // resultados :  )
        System.out.println("\nResultado do teste:");
        if (respostasPositivas >= 7) {
            System.out.println("Você apresenta fortes indícios de ansiedade. Recomenda-se procurar terapia.");
        } else if (respostasPositivas >= 4) {
            System.out.println("Atenção aos sinais de ansiedade. Cuide mais de seu corpo e mente, e considere procurar auxílio médico.");
        } else {
            System.out.println("Você não apresenta muitos indícios de ansiedade.");
        }
        
        scanner.close();
    }
}